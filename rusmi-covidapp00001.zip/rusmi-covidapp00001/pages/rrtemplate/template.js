{covidData.Countries && covidData.Countries.map((country) => (
              <tr>
                <td>{country.Slug}</td>
                <td>{country.Country}</td>
                <td>{country.CountryCode}</td>
                <td>{country.Date}</td>
                <td>{country.NewConfirmed}</td>
                <td>{country.NewDeaths}</td>
                <td>{country.NewRecovered}</td>
                <td>{country.TotalConfirmed}</td>
                <td>{country.TotalDeaths}</td>
                

                <td>
                  <Button onClick={() => (console.log('clicked', country.Slug))}>
                    See Detail
                  </Button>
                </td>
              </tr>
            ))}

//GETLive By Country And Status
//

