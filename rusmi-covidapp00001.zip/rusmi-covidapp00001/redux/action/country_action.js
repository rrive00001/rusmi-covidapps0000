export const updateCountryDetails = value => ({
  type: "UPDATE",
  payload: value
});
