export const updateUser = value => ({
  type: "UPDATE",
  payload: value
});
