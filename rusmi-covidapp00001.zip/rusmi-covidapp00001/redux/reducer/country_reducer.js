const initState = {
    Country : "",
    CountryCode : "",
    NewConfirmed:0, 
    NewDeaths:0,
    NewRecovered:0,
};

export const countryReducer = (state = initState, action) => {
  switch (action.type) {
    case "UPDATE":
      return { ...state, ...action.payload };
    default:
      return state;
  }
};
