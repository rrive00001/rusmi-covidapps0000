import { combineReducers } from "redux";
import { userReducer } from "./user_reducer";
import { countryReducer } from "./country_reducer";

export default combineReducers({
  userReducer,
  countryReducer
});
