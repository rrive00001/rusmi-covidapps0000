import Head from "next/head";
import Image from "next/image";
import styles from "../styles/Home.module.css";
import 'bootstrap/dist/css/bootstrap.min.css';
import Button from 'react-bootstrap/Button';
import Stack from 'react-bootstrap/Stack';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Alert from 'react-bootstrap/Alert';
//import { Button } from "react-bootstrap";
import Link from "next/link";
import axios from "axios";

export default function PersonList(personList) {
  return (
    <div className={styles.container}>
      

    </div>
  );
}
