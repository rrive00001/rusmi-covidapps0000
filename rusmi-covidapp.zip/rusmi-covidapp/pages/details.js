import React, { Component } from "react";
import { connect } from "react-redux";
import axios from "axios";
import PersonList from "./PersonList";
import { Button } from "react-bootstrap";
import Card from 'react-bootstrap/Card';
import Stack from 'react-bootstrap/Stack';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Alert from 'react-bootstrap/Alert';
import Table from 'react-bootstrap/Table';

// import Link from "next/link";
// import Head from "next/head";
// import Image from "next/image";
// import styles from "../styles/Home.module.css";
// import 'bootstrap/dist/css/bootstrap.min.css';
// import Button from 'react-bootstrap/Button';


// 
export default class App extends Component {
  constructor() {
    super();
    this.state = {
      covidData: {},
    };
  }

  componentDidMount() {
    this.getCovidData();
  }

  getCovidData = async () => {
    const { data } = await axios.get(
      "https://api.covid19api.com/summary"
    );
    console.log("ini ringkasan data covid global", data);
    //console.log('clicked', country.Slug);
    this.setState({ covidData: data });
  };

  render() {
    const{ covidData } = this.state
    return (
      <>
        <Table striped bordered hover variant="dark">
            <thead>
              <tr>
                <th>Country Name</th>
                <th>Country Code</th>
                <th>Date</th>
                <th>New Confirmed</th>
                <th>New Deaths</th>
                <th>New Recovered</th>
                <th>Total Confirmed</th>
                <th>Total Deaths</th>
              </tr>
            </thead>
            <tbody>
              {covidData.Countries && covidData.Countries.map((country) => (
                <tr>
                  <td>{country.Country}</td>
                  <td>{country.CountryCode}</td>
                  <td>{country.Date}</td>
                  <td>{country.NewConfirmed}</td>
                  <td>{country.NewDeaths}</td>
                  <td>{country.NewRecovered}</td>
                  <td>{country.TotalConfirmed}</td>
                  <td>{country.TotalDeaths}</td>
                </tr>
              ))}
            </tbody>
        </Table>
      </>
    );
  }
}
