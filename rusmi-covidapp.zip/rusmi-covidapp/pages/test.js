import React, { Component } from "react";
import axios from "axios";
import PersonList from "./PersonList";
import 'bootstrap/dist/css/bootstrap.min.css';
import { Button } from "react-bootstrap";
import Card from 'react-bootstrap/Card';
import Stack from 'react-bootstrap/Stack';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Alert from 'react-bootstrap/Alert';
import Table from 'react-bootstrap/Table';
import { connect } from "react-redux";
import { updateCountryDetails } from '../redux/action/country_action';
import PropTypes from 'prop-types';
import {createStore} from "redux";
import Router from "next/router";


// import Link from "next/link";
// import Head from "next/head";
// import Image from "next/image";
// import styles from "../styles/Home.module.css";
// import 'bootstrap/dist/css/bootstrap.min.css';
// import Button from 'react-bootstrap/Button';


// 
class App extends Component {
  constructor() {
    super();
    this.state = {
      covidData: {},
    };
  }

  componentDidMount() {
    this.getCovidData();
  }

  getCovidData = async () => {
    const { data } = await axios.get(
      "https://api.covid19api.com/summary"
    );
    console.log("ini ringkasan data covid global", data);
    //console.log('clicked', country.Slug);
    this.setState({ covidData: data });
  };


  getCovidDataDetails(country) {
    console.log('clicked', country);                   
    this.props.dispatch(updateCountryDetails({
    Country : country.Country,
    CountryCode : country.CountryCode,
    NewConfirmed:country.NewConfirmed,
    NewDeaths:country.NewDeaths,
}))
Router.push(`/details/${country.Slug}`)

  }

  render() {
    const{ covidData } = this.state
    return (
      <>
      {[
        'Primary',
       ].map((variant) => (
        <Card
          bg={variant.toLowerCase()}
          key={variant}
          text={variant.toLowerCase() === 'light' ? 'dark' : 'white'}
          style={{ width: '18rem' }}
          className="mb-2"
        >
          <Card.Header>Positive Case</Card.Header>
          <Card.Body>
            <Card.Title>{covidData?.Global?.TotalConfirmed} </Card.Title>
          </Card.Body>
        </Card>
      ))}


        <Table striped bordered hover variant="dark">
            <thead>
              <tr>
                <th>Country Name</th>
                <th>Total Confirmed</th>
                <th>Total Deaths</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {covidData.Countries && covidData.Countries.map((country) => (
                <tr>
                  <td>{country.Country}</td>
                  <td>{country.TotalConfirmed}</td>
                  <td>{country.TotalDeaths}</td>
                  <td>
                    <Button onClick={() => this.getCovidDataDetails(country)}>
                      See Detail
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
        </Table>
      </>
    );
  }
}

//buat connect redux ke component
const mapStateToProps = state => ({
  countryReducer: state.countryReducer
});

export default connect(mapStateToProps)(App);
