import React, { Component } from "react";
import axios from "axios";
import PersonList from "../PersonList";
import { Button } from "react-bootstrap";
import Card from 'react-bootstrap/Card';
import Stack from 'react-bootstrap/Stack';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Alert from 'react-bootstrap/Alert';
import Table from 'react-bootstrap/Table';

// import Link from "next/link";
// import Head from "next/head";
// import Image from "next/image";
// import styles from "../styles/Home.module.css";
// import 'bootstrap/dist/css/bootstrap.min.css';
// import Button from 'react-bootstrap/Button';


// 
export default class App extends Component {
  constructor() {
    super();
    this.state = {
      covidData: {},
    };
  }

  componentDidMount() {
    this.getCovidData();
  }

  getCovidData = async () => {
    const { data } = await axios.get(
      "https://api.covid19api.com/summary"
    );
    console.log("ini data covid global", data);
    //console.log('clicked', country.Slug);
    this.setState({ covidData: data });
  };

  render() {
    const{ covidData } = this.state
    return (
      <>
      <Card style={{ width: '18rem' }}>
        <Card.Body>
          <Card.Title>Positive Case</Card.Title>
          <Card.Text>
            {covidData?.Global?.TotalConfirmed}
          </Card.Text>
        </Card.Body>
      </Card>

        <Table striped bordered hover variant="dark">
          <thead>
            <tr>
              <th>Country Name</th>
              <th>Total Confirmed</th>
              <th>Total Total Deaths</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {covidData.Countries && covidData.Countries.map((country) => (
              <tr>
                <td>{country.Country}</td>
                <td>{country.TotalConfirmed}</td>
                <td>{country.TotalDeaths}</td>
                <td>
                  <Button onClick={() => (console.log('clicked', country.Slug))}>
                    See Detail
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
    </Table>


        <Button onClick={this.addNewUser}>Add New user</Button>
        <PersonList
          personList={this.state.personList}
          deletePerson={(id) => {
            this.deletePerson(id);
          }}
        />
      </>
    );
  }
}
