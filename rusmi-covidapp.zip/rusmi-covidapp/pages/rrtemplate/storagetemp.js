
//setItem() - add a key and a value to localStorage
localStorage.setItem("user", JSON.stringify({ nama: "Andi", umur: 17}));

// object in string
localStorage.getItem("user");
// object in JSON
const user = JSON.parse(localStorage.getItem("user"));
//clear() - delete all instances of localStorage
localStorage.clear();

// removeItem() - delete an item from localStorage based on its key
localStorage.setItem("name", "Budi");
localStorage.setItem("umur", "18");
localStorage.removeItem("name");

//key() - When you supply a number, it aids in the retrieval of a localStorage key.
localStorage.setItem("name", "Budi");
localStorage.setItem("umur", "18");
localStorage.removeItem("name");

//key() - When you supply a number, it aids in the retrieval of a localStorage key.
localStorage.setItem("user", JSON.stringify({ nama: "Andi", umur: 17}));
localStorage.setItem("skin_theme", "dark");
localStorage.key(0); 


//====================================================================
//Implement localStorage with Redux (store.js)
// convert object to string and store in localStorage
function saveToLocalStorage(state) {
 try {
 const serialisedState = JSON.stringify(state);
 localStorage.setItem("cooderuStorage", serialisedState);
 } catch (e) {
 console.warn(e);
 }
 }

 // load string from localStarage and convert into an Object
 // invalid output must be undefined
 function loadFromLocalStorage() {
 try {
 const serialisedState = localStorage.getItem("cooderuStorage");
 if (serialisedState === null) return undefined;
 return JSON.parse(serialisedState);
 } catch (e) {
 console.warn(e);
 return undefined;
 }
 }

 //// load string from localStarage and convert into an Object
 // invalid output must be undefined
 function loadFromLocalStorage() {
 try {
 const serialisedState = localStorage.getItem("cooderuStorage");
 if (serialisedState === null) return undefined;
 return JSON.parse(serialisedState);
 } catch (e) {
 console.warn(e);
 return undefined;
 }
 }

 //create our store from our rootReducers and use loadFromLocalStorage
// to overwrite any values that we already have saved
const store = createStore(rootReducer, loadFromLocalStorage(), 
applyMiddleware(logger));
// listen for store changes and use saveToLocalStorage to
// save them to localStorage
store.subscribe(() => saveToLocalStorage(store.getState()));
export default store;

