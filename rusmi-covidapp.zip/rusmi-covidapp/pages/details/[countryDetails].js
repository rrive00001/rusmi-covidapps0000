import React, { Component } from "react";
import { useRouter } from 'next/router'
import { connect } from "react-redux";
import { Button } from "react-bootstrap";
import Card from 'react-bootstrap/Card';
import Stack from 'react-bootstrap/Stack';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Alert from 'react-bootstrap/Alert';
import Table from 'react-bootstrap/Table';
//import {createStore} from "redux";
//import { saveToLocalStorage, loadFromLocalStorage } from "/redux/helper";

/*
untuk button set local storage?

<Button as="a" variant="primary" onClick={() => {
                            localStorage.setItem(
                                <h1>Country : {props.countryReducer.Country}<br/>
                                    New Deaths : {props.countryReducer.NewDeaths}<br/>
                                    New Confirmed : {props.countryReducer.NewConfirmed}<br/>
                                    New Recovered : {props.countryReducer.NewRecovered}<br/></h1>
                                );
                            }}>
                            Set LocalStorage
                        </Button>


*/

const CountryDetail = (props) => {
  return <div>
            <h1>Country : {props.countryReducer.Country}<br/>
             New Deaths : {props.countryReducer.NewDeaths}<br/>
             New Confirmed : {props.countryReducer.NewConfirmed}<br/>
             New Recovered : {props.countryReducer.NewRecovered}<br/></h1>

             <Container>
                <Row>
                    <Col> {[
                            'Primary',
                            ].map((variant) => (
                                <Card
                                bg={variant.toLowerCase()}
                                key={variant}
                                text={variant.toLowerCase() === 'light' ? 'dark' : 'white'}
                                style={{ width: '18rem' }}
                                className="mb-2"
                                >
                                    <Card.Header>Country</Card.Header>
                                    <Card.Body>
                                        <Card.Title>{props.countryReducer.Country} </Card.Title>
                                    </Card.Body>
                                </Card>
                        ))}
                    
                    </Col>
                    
                    <Col>
                            {[
                            'Danger',
                            ].map((variant) => (
                                <Card
                                bg={variant.toLowerCase()}
                                key={variant}
                                text={variant.toLowerCase() === 'light' ? 'dark' : 'white'}
                                style={{ width: '18rem' }}
                                className="mb-2"
                                >
                                    <Card.Header>New Deaths</Card.Header>
                                    <Card.Body>
                                        <Card.Title>{props.countryReducer.NewDeaths} </Card.Title>
                                    </Card.Body>
                                </Card>
                        ))}
                    </Col>
                    
                </Row>
                <Row>
                    <Col>
                            {[
                               'Info',
                            ].map((variant) => (
                                <Card
                                bg={variant.toLowerCase()}
                                key={variant}
                                text={variant.toLowerCase() === 'light' ? 'dark' : 'white'}
                                style={{ width: '18rem' }}
                                className="mb-2"
                                >
                                    <Card.Header>New Confirmed</Card.Header>
                                    <Card.Body>
                                        <Card.Title>{props.countryReducer.NewConfirmed}</Card.Title>
                                    </Card.Body>
                                </Card>
                        ))}
                    </Col>
                    <Col>
                        {[
                            'Success',
                            ].map((variant) => (
                                <Card
                                bg={variant.toLowerCase()}
                                key={variant}
                                text={variant.toLowerCase() === 'light' ? 'dark' : 'white'}
                                style={{ width: '18rem' }}
                                className="mb-2"
                                >
                                    <Card.Header>New Recovered</Card.Header>
                                    <Card.Body>
                                        <Card.Title>{props.countryReducer.NewRecovered}</Card.Title>
                                    </Card.Body>
                                </Card>
                        ))}
                    
                    </Col>
                    
                </Row>
                <Row>
                    <Col>
                        <Button>
                            Set LocalStorage
                        </Button>
                    
                    </Col>
                </Row>


                </Container>
                <br/>

                
    </div>

        
            


}


const mapStateToProps = state => ({
  countryReducer: state.countryReducer
});

export default connect(mapStateToProps)(CountryDetail);


//export default CountryDetail